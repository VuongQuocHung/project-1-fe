// onfocus + onblur + onkeyup
// const inputSearch = document.querySelector(".input-search");
// const suggestList = document.querySelector(".suggest-list");
// const title = document.querySelector(".title");

// // onfocus
// inputSearch.onfocus = () => {
//   suggestList.setAttribute("show", "1");
// }

// // onblur
// inputSearch.onblur = () => {
//   suggestList.setAttribute("show", "0");
// }

// // onkeyup
// inputSearch.onkeyup = () => {
//   if(inputSearch.value.length > 0) {
//     title.innerHTML = inputSearch.value;
//   } else {
//     title.innerHTML = "New Item";
//   }
// }



// onclick
// const buttonContact = document.querySelector(".button-contact");
// const contactList = document.querySelector(".contact-list");

// buttonContact.onclick = () => {
//   if(contactList.getAttribute("show") == "0") {
//     contactList.setAttribute("show", "1");
//     buttonContact.innerHTML = "x";
//   } else {
//     contactList.setAttribute("show", "0");
//     buttonContact.innerHTML = "Liên hệ";
//   }
// }


// const listButtonTab = document.querySelectorAll(".button-tab");
// listButtonTab.forEach((button) => {
//   button.onclick = () => {
//     const tab = button.getAttribute("tab");
//     switch (tab) {
//       case "dien-thoai":
//         console.log("Gửi yêu cầu lên backend lấy danh sách điện thoại");
//         break;
//       case "laptop":
//         console.log("Gửi yêu cầu lên backend lấy danh sách laptop");
//         break;
//       case "phu-kien":
//         console.log("Gửi yêu cầu lên backend lấy danh sách phụ kiện");
//         break;
//       case "pc":
//         console.log("Gửi yêu cầu lên backend lấy danh sách PC");
//         break;
//     }
//   }
// });



// onchange
const filter = document.querySelector(".filter");
filter.onchange = () => {
  const option = filter.value;
  switch (option) {
    case "gia-thap-den-cao":
      console.log("Gửi yêu cầu lên backend lấy danh sách giá thấp đến cao");
      break;
    case "gia-cao-den-thap":
      console.log("Gửi yêu cầu lên backend lấy danh sách giá cao đến thấp");
      break;
    case "giam-gia-nhieu":
      console.log("Gửi yêu cầu lên backend lấy danh sách giảm giá nhiều");
      break;
    default:
      console.log("Gửi yêu cầu lên backend lấy danh sách mặc định");
      break;
  }
}