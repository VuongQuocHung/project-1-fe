// 3.1. Nội dung trong thẻ HTML
// const title = document.querySelector(".title");
// console.log(title.innerHTML); // Lấy ra nội dung
// title.innerHTML = "Tiêu đề mới"; // Thay đổi nội dung


// 3.2. Thuộc tính thẻ HTML
// const buttonAddCart = document.querySelector(".button-add-cart");
// Lấy ra thuộc tính
// const productId = buttonAddCart.getAttribute("product-id");
// console.log(productId);
// Gán lại giá trị cho thuộc tính
// buttonAddCart.setAttribute("product-id", "2");