// 2.1. getElementById
// const buttonCreateProduct = document.getElementById("button-create-product");
// console.log(buttonCreateProduct);


// 2.2. getElementsByTagName
// const listButtonEditProduct = document.getElementsByTagName("button");
// console.log(listButtonEditProduct);


// 2.3. getElementsByClassName
// const listButtonEditProduct = document.getElementsByClassName("inner-edit");
// console.log(listButtonEditProduct);


// 2.4. querySelector (Chỉ dùng cái này)
// const buttonCreateProduct = document.querySelector(".section-1 .inner-create");
// console.log(buttonCreateProduct);

// const buttonCreateArticle = document.querySelector(".section-2 .inner-create");
// console.log(buttonCreateArticle);


// 2.5. querySelectorAll (Chỉ dùng cái này)
// const listButtonEditProduct = document.querySelectorAll(".section-1 .inner-edit");
// console.log(listButtonEditProduct);